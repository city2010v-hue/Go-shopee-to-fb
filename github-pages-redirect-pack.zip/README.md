
# GitHub Pages Redirect (Shopee Affiliate ➜ Facebook)

หน้านี้สร้างไว้เพื่อใช้งาน **ฟรี** บน GitHub Pages (ไม่ต้องมีเซิร์ฟเวอร์) โดยตรรกะคือ
1) เปิดแท็บ Shopee ด้วยลิงก์ Affiliate (เพื่อวางคุกกี้)
2) จากนั้นแท็บปัจจุบัน redirect ไปยังโพสต์ Facebook โดยอัตโนมัติ

## วิธีติดตั้ง (ครั้งแรก 3-5 นาที)

### 1) สร้าง GitHub Repo
- สมัคร/ล็อกอิน GitHub: https://github.com
- กด **New repository**
- ตั้งชื่ออะไรก็ได้ เช่น `go-shopee-to-fb`
- เลือก **Public**
- กด **Create repository**

### 2) เปิดใช้ GitHub Pages
- เข้าเมนู **Settings** ของ repo นี้
- ซ้ายมือเลือก **Pages**
- ในหัวข้อ **Build and deployment**:
  - Source: **Deploy from a branch**
  - Branch: เลือก **main** และ **/(root)**
- กด **Save**
- จะได้ URL ประมาณ `https://<username>.github.io/go-shopee-to-fb/` (ถ้ายังไม่ขึ้นให้รอสักครู่แล้ว refresh)

### 3) อัปโหลดไฟล์
- กลับไปหน้า repo > กด **Add file** > **Upload files**
- ลากไฟล์ `index.html` นี้ขึ้นไป (ไฟล์นี้ต้องอยู่ที่โฟลเดอร์ root ของ repo)
- กด **Commit changes**

### 4) ทดสอบลิงก์
- เปิด URL GitHub Pages ที่ได้ (ตัวอย่าง: `https://<username>.github.io/go-shopee-to-fb/`)
- คลิกปุ่ม **“คลิกเพื่อไปต่อ”**
- จะมีแท็บ Shopee (affiliate) เปิดขึ้น และแท็บเดิมจะเด้งไป Facebook ภายใน ~1.5 วินาที

> หมายเหตุ: ถ้าถูกบล็อกป็อปอัป ให้อนุญาตชั่วคราวหรือคลิกปุ่มซ้ำอีกครั้ง

## เปลี่ยนปลายทาง/ลิงก์ Affiliate

เปิดไฟล์ `index.html` แล้วแก้ค่าตัวแปรสองตัวนี้ในสคริปต์:
```js
var shopee = "https://s.shopee.co.th/1LWm2PezKj";
var target = "https://www.facebook.com/.......";
```
จากนั้น commit และรอสักครู่ หน้าเพจจะอัปเดตอัตโนมัติ

## เคล็ดลับ Conversion
- ถ้ากลัว cookie ยังไม่วางทัน ให้เพิ่มดีเลย์จาก `1500` (1.5 วินาที) เป็น `2000`-`3000` มิลลิวินาที
- ลองทดสอบทั้งบน Wi‑Fi/4G และเบราว์เซอร์ยอดนิยม (Safari/Chrome)
- หลีกเลี่ยงการใช้วิธี cloaking หลอก bot (ผิดกฎหลาย network)

—
Made for you 💙
